function apostar(){
    let b=101; //ingrese al ciclo while
    let intentos=0;//contador de intentos
    var a=Math.round(Math.random()*100); //genera númerop al azar entre 0 y 100
    //ciclo while
    while (a!=b){
        intentos++;
        b=parseInt(prompt('Ingrese valor apostado de 0 y 100'));
        //
        if(b>a){
            alert('EL VALOR MÁS BAJO');
        }else{
            alert('EL VALOR ES MÁS ALTO');
        }
        intentos++;
    }
    document.getElementById('apostado').value=b;
    document.getElementById('resultado').value=a;
    swal('FELICITACIONES USUARIO','HAZ ACERTADO NÚMERO EXITOSAMENTE')
    document.getElementById('salida').value='HAZ ACERTADO NÚMERO A LOS...'+intentos+'..intentos';
}
function cancel(){
    document.getElementById('apostado').value='';
    document.getElementById('resultado').value='';
    document.getElementById('apostado').value='';
}