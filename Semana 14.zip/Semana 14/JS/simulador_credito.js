function calcular(){
    var n1= document.getElementById('valorc').value;//del form al js
    var n2=document.getElementById('numc').value;
    var n3=document.getElementById('interes').value;
    //proceso de calcular
    var valorA=parseFloat(n1)*parseFloat(n3);
    var valorB=(parseFloat(n1)+(1+parseFloat(n2)*parseFloat(n3)));
    document.getElementById('valorA').value=valorA
    document.getElementById('valorB').value=valorB
}
function limpiar(){
    document.getElementById("valorc").value=" ";// borrar input de entrada
    document.getElementById("numc").value=" ";
    document.getElementById("interes").value=" ";
}